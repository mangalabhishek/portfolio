#include<bits/stdc++.h>
using namespace std;
class Node{
    public:
        int data;
        Node* left;
        Node* right;
        
        Node(int val){
            this->data=val;
            this->left=NULL;
            this->right=NULL;
        }
};
Node* insertIntoBST(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return root;
    }
    
    if(data > root->data){
        root->right=insertIntoBST(root->right,data);
    }else{
        root->left=insertIntoBST(root->left,data);
    }
    return root;
    
}
void takeInput(Node* &root){
    int data;
    cin>>data;
    
    while(data!=-1){
        root=insertIntoBST(root,data);
        cin>>data;
    }
}
void inorder(Node* root,vector<int>& v){
    if(root==NULL)
        return;
        
    inorder(root->left,v);
    v.push_back(root->data);
    inorder(root->right,v);
}
void solve(Node* root,vector<int>v,int &i){
    if(root==NULL)
        return;
    
    root->data=v[i++];
    solve(root->left,v,i);
    solve(root->right,v,i);
}
void levelOrderTraversal(Node* root){
    queue<Node*>q;
    q.push(root);
    q.push(NULL);
    
    while(!q.empty()){
        Node* temp=q.front();
        q.pop();
        
        if(temp==NULL){
            cout<<endl;
            if(!q.empty())
                q.push(NULL);
        }else{
            cout<<temp->data<<" ";
            if(temp->left){
            q.push(temp->left);
            }
            if(temp->right){
                q.push(temp->right);
            }
            
        }
        
        
    }
}
//4 2 6 1 3 5 7 -1
int main(){
    Node* root=NULL;
    cout<<"Enter data to create BST"<<endl;
    takeInput(root);
    vector<int>v;
    inorder(root,v);
    for(int i: v){
        cout<<i<<" ";
    }cout<<endl;
    //levelOrderTraversal(root);
    int i=0;
    solve(root,v,i);
    
    levelOrderTraversal(root);
    
}