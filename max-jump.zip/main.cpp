#include<bits/stdc++.h>
using namespace std;
 int main(){
     
     vector<int>nums={1,3,6,4,1,2};
     int target=2;
     int i=0;
     int jump=0;
     int j=i+1;
     while(j<=nums.size()-1){
         
         if(abs(nums[j]-nums[i])<=target){
            jump++;
            i=j;
            j=i+1;
            cout<<i<< " " <<j <<jump<<endl;
        }else{
            j++;
        }
    }
    // if(jump!=0){
    //     cout<< jump;
    // }else{
    //     cout<< -1;
    // }
     
 }