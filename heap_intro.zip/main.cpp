#include<iostream>
using namespace std;
class heap{
    public:
    int size;
    int arr[n];
    
    heap(){
        size=0;
        arr[0]=-1;
    }
    
    void insert(int val){
        size=size+1;
        int index=size;
        arr[index]=val;
        
        while(index>1){
            int parent=index/2;
            if(val > arr[parent]){
                swap(val,arr[parent]);
                index=parent;
            }
            else{
                return;
            }
        }
    }
    
    void delete(){
        arr[1]=arr[size];
        size=size-1;
        
        int i=1;
        while(i<size){
            int left=2*i;
            int right=2*i+1;
            
            if(left <size && arr[left] > arr[i]){
                swap(arr[left],arr[i]);
                i=left;
            }else if(right<size && arr[right] > arr[i]){
                swap(arr[right],arr[i]);
                i=right;
            }else{
                return;
            }
        }
    }
    
};
int main(){
    
}