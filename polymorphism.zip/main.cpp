#include<iostream>
using namespace std;
class Complex{
    private:
    int a;
    // int b;
    
    public:
    Complex(int a){
        this->a=a;
    }
    
    void operator +(Complex &b){
        cout<<this->a<<endl;
        cout<<b.a<<endl;
        
        
    }
    
    void operator() (){
        cout<<"main bracket hu "<< this->a<<endl;
    }
    
};

int main(){
    Complex obj1(5);
    Complex obj2(4);
    
    
    obj1+obj2;
    obj1();
    
    
}